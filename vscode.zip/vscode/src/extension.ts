// src/extension.ts
/* eslint-disable @typescript-eslint/no-floating-promises */
import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import * as os from 'os';
import * as dgram from 'dgram';
import { execFile } from 'child_process';
import * as util from 'util';

const execFileP = util.promisify(execFile);

// ================== CONFIG ==================
const CONFIG_NS = 'lasecplot';
const CFG_UDP_ADDRESS = 'udpAddress';
const CFG_UDP_PORT = 'udpPort';
const CFG_CMD_UDP_PORT = 'cmdUdpPort';

// ================== TIPOS ===================
type PortLite = {
  path: string;
  friendlyName?: string;
  devicePath?: string;
  manufacturer?: string;
  isVirtual?: boolean;
  _source?: string;
};

// ================== ESTADO GLOBAL ==================
let udpServer: dgram.Socket | null = null;
let currentPanel: vscode.WebviewPanel | null = null;
const _disposables: vscode.Disposable[] = [];
let statusBarIcon: vscode.StatusBarItem;
let ctxGlobal: vscode.ExtensionContext;

// ================== LOG PARA WEBVIEW ==================
function postLog(level: 'debug' | 'info' | 'warn' | 'error', msg: string, data?: unknown) {
  currentPanel?.webview.postMessage({ type: 'log', level, msg, data, ts: Date.now() });
}

// ================== CONFIG ==================
function getConfig() {
  const cfg = vscode.workspace.getConfiguration(CONFIG_NS);
  const udpAddress = cfg.get<string>(CFG_UDP_ADDRESS, '127.0.0.1');
  const udpPort = cfg.get<number>(CFG_UDP_PORT, 47269);
  const cmdUdpPort = cfg.get<number>(CFG_CMD_UDP_PORT, 47268);
  return { cfg, udpAddress, udpPort, cmdUdpPort };
}

function updateStatusBar(udpPort: number, cmdUdpPort: number) {
  if (!statusBarIcon) return;
  statusBarIcon.text = `$(graph-line) LasecPlot`;
  statusBarIcon.tooltip = `UDP ${udpPort} • CMD ${cmdUdpPort}`;
  statusBarIcon.show();
}

function bindUdpServer(udpPort: number, cmdUdpPort: number) {
  if (udpServer) {
    try { udpServer.close(); } catch { /* ignore */ }
    udpServer = null;
  }
  udpServer = dgram.createSocket('udp4');
  udpServer.bind(udpPort);

  udpServer.on('message', (msg: Buffer) => {
    currentPanel?.webview.postMessage({
      data: msg.toString(),
      fromSerial: false,
      timestamp: Date.now()
    });
  });

  udpServer.on('error', (err) => postLog('error', '[UDP] server error', String(err)));
  updateStatusBar(udpPort, cmdUdpPort);
}

async function saveAddressPort(address: string, port: number) {
  const { cfg, udpPort, cmdUdpPort } = getConfig();
  await cfg.update(CFG_UDP_ADDRESS, address, vscode.ConfigurationTarget.Global);
  if (udpPort !== port) {
    await cfg.update(CFG_UDP_PORT, port, vscode.ConfigurationTarget.Global);
    bindUdpServer(port, cmdUdpPort);
  } else {
    updateStatusBar(udpPort, cmdUdpPort);
  }
}

async function saveCmdPort(port: number) {
  const { cfg, udpPort, cmdUdpPort } = getConfig();
  if (cmdUdpPort !== port) {
    await cfg.update(CFG_CMD_UDP_PORT, port, vscode.ConfigurationTarget.Global);
    updateStatusBar(udpPort, port);
  }
}

// ================== ATIVAÇÃO ==================
export function activate(context: vscode.ExtensionContext) {
  ctxGlobal = context;

  statusBarIcon = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBarIcon.command = 'lasecplot.start';
  context.subscriptions.push(statusBarIcon);

  context.subscriptions.push(
    vscode.commands.registerCommand('lasecplot.start', () => openPanel())
  );

  const { udpPort, cmdUdpPort } = getConfig();
  updateStatusBar(udpPort, cmdUdpPort);
  statusBarIcon.show();
}

export function deactivate() {
  try { udpServer?.close(); } catch { /* ignore */ }
}

// ================== WEBVIEW / PAINEL ==================
function openPanel() {
  const { udpAddress, udpPort, cmdUdpPort } = getConfig();
  const column: vscode.ViewColumn =
    vscode.window.activeTextEditor?.viewColumn ?? vscode.ViewColumn.One;

  if (currentPanel) {
    currentPanel.reveal(column, false);
    return;
  }

  const panel = vscode.window.createWebviewPanel(
    'lasecplot',
    'LasecPlot',
    column,
    {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.file(path.join(ctxGlobal.extensionPath, 'media'))],
      retainContextWhenHidden: true,
      enableCommandUris: true,
    }
  );
  currentPanel = panel;

  // Carrega media/index.html e reescreve URLs
  fs.readFile(path.join(ctxGlobal.extensionPath, 'media', 'index.html'), (err, data) => {
    if (err) { postLog('error', 'read index.html failed', String(err)); return; }
    let rawHTML = data.toString();

    const srcList = rawHTML.match(/src="(.*?)"/g) ?? [];
    const hrefList = rawHTML.match(/href="(.*?)"/g) ?? [];
    for (const attr of [...srcList, ...hrefList]) {
      const url = attr.split('"')[1];
      const extensionURI = vscode.Uri.joinPath(ctxGlobal.extensionUri, "./media/" + url);
      const webURI = panel.webview.asWebviewUri(extensionURI);
      const toReplace = attr.replace(url, webURI.toString());
      rawHTML = rawHTML.replace(attr, toReplace);
    }

    // força dark como padrão se placeholder existir
    const lasecplotStyle = rawHTML.match(/(.*)_lasecplot_default_color_style(.*)/g);
    if (lasecplotStyle != null) {
      rawHTML = rawHTML.replace(lasecplotStyle.toString(), 'var _lasecplot_default_color_style = "dark";');
    }

    panel.webview.html = rawHTML;

    // envia config inicial
    panel.webview.postMessage({
      type: 'initConfig',
      udpAddress,
      udpPort,
      cmdUdpPort,
    });

    // já sobe o UDP
    bindUdpServer(udpPort, cmdUdpPort);
  });

  panel.onDidDispose(() => {
    if (udpServer) {
      try { udpServer.close(); } catch { /* ignore */ }
      udpServer = null;
    }
    while (_disposables.length) {
      const x = _disposables.pop();
      if (x) x.dispose();
    }
    currentPanel = null;
  }, null, _disposables);

  panel.webview.onDidReceiveMessage(async (message) => {
    try {
      // LOG de front
      if (message?.type === 'frontLog') {
        postLog('info', 'frontLog', message.payload);
        return;
      }

      // salvar host/port de dados
      if (message?.type === 'saveAddressPort') {
        const host = String(message.host || '').trim();
        const portNum = Number(message.port);
        if (host && Number.isFinite(portNum)) {
          await saveAddressPort(host, portNum);
        }
        return;
      }

      // salvar cmd port
      if (message?.type === 'saveCmdPort') {
        const portNum = Number(message.port);
        if (Number.isFinite(portNum)) {
          await saveCmdPort(portNum);
        }
        return;
      }

      // enviar payload para endereço/porta de comando
      if ('data' in message) {
        const { udpAddress: addr, cmdUdpPort: currentCmdPort } = getConfig();
        const buf: Buffer = Buffer.isBuffer(message.data)
          ? message.data
          : Buffer.from(String(message.data));
        const udpClient = dgram.createSocket('udp4');
        udpClient.send(buf, 0, buf.length, currentCmdPort, addr || '127.0.0.1', () => {
          udpClient.close();
        });
        return;
      }

      // comandos gerais
      if ('cmd' in message) {
        runCmd(message);
        return;
      }
    } catch (e) {
      postLog('error', 'onDidReceiveMessage error', String(e));
    }
  }, null, _disposables);
}

// ================== COMANDOS ==================
async function runCmd(msg: any) {
  const id: string = ('id' in msg) ? msg.id : '';

  if (msg.cmd === 'listSerialPorts') {
    try {
      const list = await listSerialPortsCross();
      currentPanel?.webview.postMessage({ id, cmd: 'serialPortList', list });
    } catch (err) {
      postLog('error', 'listSerialPorts failed', String(err));
      currentPanel?.webview.postMessage({ id, cmd: 'serialPortList', list: [] as PortLite[] });
    }
    return;
  }

  if (msg.cmd === 'saveFile') {
    try {
      exportDataWithConfirmation(path.join(msg.file.name), { JSON: ['json'] }, msg.file.content);
    } catch (error: any) {
      void vscode.window.showErrorMessage("Couldn't write file: " + error);
    }
    return;
  }
}

// ================== SAVE DIALOG ==================
function exportDataWithConfirmation(fileName: string, filters: { [name: string]: string[] }, data: string): void {
  void vscode.window.showSaveDialog({
    defaultUri: vscode.Uri.file(fileName),
    filters,
  }).then((uri: vscode.Uri | undefined) => {
    if (uri) {
      const value = uri.fsPath;
      fs.writeFile(value, data, (error: any) => {
        if (error) {
          void vscode.window.showErrorMessage('Could not write to file: ' + value + ': ' + error.message);
        } else {
          void vscode.window.showInformationMessage('Saved ' + value);
        }
      });
    }
  });
}

// ================== LISTA DE PORTAS (helper + fallback) ==================
function platformSubdir(): { subdir: string; exe: string } {
  const arch = process.arch;       // 'x64', 'arm64', 'ia32'
  const plat = process.platform;   // 'win32', 'linux', 'darwin'
  let subdir = '';

  if (plat === 'win32') {
    if (arch === 'x64') subdir = 'win32-x64';
    else if (arch === 'arm64') subdir = 'win32-arm64';
    else subdir = 'win32-x64';
  } else if (plat === 'linux') {
    if (arch === 'arm64') subdir = 'linux-arm64';
    else subdir = 'linux-x64';
  } else if (plat === 'darwin') {
    if (arch === 'arm64') subdir = 'darwin-arm64';
    else subdir = 'darwin-x64';
  }
  const exe = plat === 'win32' ? 'lasecplot-helper.exe' : 'lasecplot-helper';
  return { subdir, exe };
}

function findHelperBinary(): { fullPath: string; tried: string[] } {
  const arch = process.arch;       // 'x64', 'arm64', ...
  const plat = process.platform;   // 'win32', 'linux', 'darwin'
  const exe = plat === 'win32' ? 'lasecplot-helper.exe' : 'lasecplot-helper';

  let subdir = '';
  if (plat === 'win32') subdir = arch === 'arm64' ? 'win32-arm64' : 'win32-x64';
  else if (plat === 'linux') subdir = arch === 'arm64' ? 'linux-arm64' : 'linux-x64';
  else if (plat === 'darwin') subdir = arch === 'arm64' ? 'darwin-arm64' : 'darwin-x64';

  const tried: string[] = [];

  // 1) <ext>/bin/<subdir>/exe   (no F5, <ext> == .../vscode)
  const p1 = path.join(ctxGlobal.extensionPath, 'bin', subdir, exe);
  tried.push(p1);
  if (fs.existsSync(p1)) return { fullPath: p1, tried };

  // 2) <ext>/out/../bin/<subdir>/exe  (quando rodando JS já compilado)
  const p2 = path.join(__dirname, '..', 'bin', subdir, exe);
  tried.push(p2);
  if (fs.existsSync(p2)) return { fullPath: p2, tried };

  // 3) cwd/bin/<subdir>/exe  (se o CWD for a própria pasta da extensão)
  const p3 = path.join(process.cwd(), 'bin', subdir, exe);
  tried.push(p3);
  if (fs.existsSync(p3)) return { fullPath: p3, tried };

  // 4) (opcional) pai de <ext>: útil se você abriu o repo na raiz por engano
  const p4 = path.join(path.dirname(ctxGlobal.extensionPath), 'bin', subdir, exe);
  tried.push(p4);
  if (fs.existsSync(p4)) return { fullPath: p4, tried };

  // 5) PATH
  tried.push(exe);
  return { fullPath: exe, tried };
}

async function listViaHelper(): Promise<PortLite[]> {
  const found = findHelperBinary();
  postLog('debug', 'Helper path resolved', found);

  try {
    if (found.fullPath !== 'lasecplot-helper.exe' && !fs.existsSync(found.fullPath)) {
      throw new Error(`Helper não encontrado. Tentativas: ${found.tried.join(' | ')}`);
    }
    const { stdout, stderr } = await execFileP(found.fullPath, ['list'], { windowsHide: true, timeout: 8000 });
    if (stderr && stderr.trim()) postLog('warn', 'helper stderr', stderr.trim());
    const arr = JSON.parse(stdout || '[]');
    if (!Array.isArray(arr)) throw new Error('stdout não é array JSON');
    for (const p of arr as PortLite[]) (p as any)._source = (p as any)._source || 'helper';
    return arr as PortLite[];
  } catch (e: any) {
    postLog('error', 'list via Go helper failed', { error: String(e), tried: found.tried });
    return [];
  }
}

// Fallback somente Windows: Registro SERIALCOMM (3ª coluna = COMx)
async function listFromRegSerialComm(): Promise<PortLite[]> {
  if (os.platform() !== 'win32') return [];
  try {
    const args = ['query', 'HKEY_LOCAL_MACHINE\\HARDWARE\\DEVICEMAP\\SERIALCOMM'];
    const { stdout } = await execFileP('reg.exe', args, { windowsHide: true, timeout: 4000 });
    const out: PortLite[] = [];
    const lines = String(stdout || '').split(/\r?\n/);

    for (const line of lines) {
      if (!/REG_SZ/i.test(line)) continue;
      const parts = line.trim().split(/\s{2,}|\t+/).filter(Boolean);
      if (parts.length >= 3) {
        const devicePath = parts[0];
        const dataCol = (parts[2] || '').trim().toUpperCase();
        if (/^COM\d+$/i.test(dataCol)) {
          out.push({
            path: dataCol,
            devicePath,
            friendlyName: devicePath,
            _source: 'SERIALCOMM'
          });
        }
      }
    }
    // De-dup
    const uniq = new Map<string, PortLite>();
    for (const p of out) uniq.set(p.path.toUpperCase(), p);
    return Array.from(uniq.values());
  } catch (e) {
    postLog('warn', 'registry SERIALCOMM failed', String(e));
    return [];
  }
}

// Junta e ordena
async function listSerialPortsCross(): Promise<PortLite[]> {
  // 1) helper (cross)
  const viaHelper = await listViaHelper();

  // 2) se Windows, MESCLA com Registro (pode trazer virtuais)
  let merged = viaHelper;
  if (os.platform() === 'win32') {
    const viaReg = await listFromRegSerialComm();
    const map = new Map<string, PortLite>();
    for (const p of viaHelper) map.set(p.path.toUpperCase(), { ...p });
    for (const r of viaReg) {
      const k = r.path.toUpperCase();
      if (map.has(k)) {
        const m = { ...map.get(k)!, ...r };
        // heurística virtual
        const hay = [m.friendlyName, m.devicePath, m.manufacturer].filter(Boolean).join(' ').toLowerCase();
        m.isVirtual = /com0com|virtual|null-?modem|emulator|loopback/.test(hay);
        m._source = (m._source ? m._source + '+' : '') + 'SERIALCOMM';
        map.set(k, m);
      } else {
        map.set(k, r);
      }
    }
    merged = Array.from(map.values());
  }

  // ordena por número
  merged.sort((a, b) => {
    const na = parseInt(String(a.path || '').replace(/[^0-9]/g, ''), 10) || 0;
    const nb = parseInt(String(b.path || '').replace(/[^0-9]/g, ''), 10) || 0;
    return na - nb;
  });

  postLog('debug', 'lista final de portas', merged);
  return merged;
}