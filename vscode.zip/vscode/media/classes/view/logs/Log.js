class Log
{
    constructor(timestamp, text)
    {
        this.timestamp = timestamp;
        this.text = text;
    }
}