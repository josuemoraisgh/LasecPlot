function my_copyArray(src_array)
{
    if (src_array == undefined) return undefined;
    
    let destArray = [];
    for (let i = 0; i < src_array.length; i++)
    {
        let copyEl;

        if (typeof(src_array[i]) == Object)
            copyEl = JSON.parse(JSON.stringify(src_array[i]));
        else
            copyEl = src_array[i];

        destArray.push(copyEl);

    }

    return destArray;
}

function isLetter(c)
{
    return ((c>='a' && c<='z') || (c>='A' && c<='Z'));
}

// protege fora do VS Code Webview
const vscode = (typeof acquireVsCodeApi === 'function') ? acquireVsCodeApi() : { postMessage: () => {} };

window.addEventListener('DOMContentLoaded', () => {
    requestSerialList();
    const btn = document.getElementById('btnRefreshSerial');
    if (btn) btn.addEventListener('click', requestSerialList);
});

function requestSerialList() {
    vscode.postMessage({ cmd: 'listSerialPorts', id: 'ui' });
}

function normalizePortItem(item) {
    const path = item.path || item.comName || item.port || item.name || '';
    const friendly = item.friendlyName || item.description || item.devicePath || item.manufacturer || '';
    const src = item._source || item.source || '';
    const isVirt = !!(item.isVirtual || /com0com|virtual|null-?modem|emulator|loopback/i.test(
    [friendly, item.pnpId, item.manufacturer, item.deviceLocation, item.productId].filter(Boolean).join(' ')
    ));
    return { path, friendly, src, isVirt };
}

function renderSerialList(list) {
    const sel = document.getElementById('serialSelect');
    if (!sel) return;

    // limpa
    while (sel.firstChild) sel.removeChild(sel.firstChild);

    // ordena por número
    list.sort((a, b) => {
    const na = parseInt(String(a.path || '').replace(/[^0-9]/g, ''), 10) || 0;
    const nb = parseInt(String(b.path || '').replace(/[^0-9]/g, ''), 10) || 0;
    if (na !== nb) return na - nb;
    return String(a.path || '').localeCompare(String(b.path || ''));
    });

    for (const raw of list) {
    const p = normalizePortItem(raw);
    if (!p.path) continue;

    const opt = document.createElement('option');
    const badge = p.isVirt ? ' [virtual]' : '';
    const src = p.src ? ` · ${p.src}` : '';
    const label = p.friendly ? `${p.path} — ${p.friendly}${badge}${src}` : `${p.path}${badge}${src}`;

    opt.value = p.path;
    opt.textContent = label;
    sel.appendChild(opt);
    }

    if (!sel.options.length) {
    const opt = document.createElement('option');
    opt.textContent = 'Nenhuma porta encontrada';
    opt.value = '';
    sel.appendChild(opt);
    }
}

window.addEventListener('message', (event) => {
    const msg = event.data || {};
    if (msg.cmd === 'serialPortList' && Array.isArray(msg.list)) {
    renderSerialList(msg.list);
    }
});
