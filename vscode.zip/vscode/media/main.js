// Init Vue

var vscode = null;
if("acquireVsCodeApi" in window) vscode = acquireVsCodeApi();

var app = initializeAppView();
// === Persistência/Config + CreateConnection estendido ===

// Detecta VS Code Webview API (se existir)
const vscode = (typeof acquireVsCodeApi === 'function') ? acquireVsCodeApi() : null;

// Cria/garante objeto configure (reativo)
if (!app.configure) {
  app.configure = {};
}
if (app.$set) {
  if (app.configure.udpAddress === undefined) app.$set(app.configure, 'udpAddress', '');
  if (app.configure.udpPort === undefined) app.$set(app.configure, 'udpPort', null);
} else {
  app.configure.udpAddress = app.configure.udpAddress || '';
  app.configure.udpPort = app.configure.udpPort || null;
}

// Utilitário: host:porta (suporta IPv6 entre [])
function parseHostPort(addr) {
  const m = String(addr || "").match(/^\s*(\[.*\]|[^:]+):(\d+)\s*$/);
  if (!m) return null;
  let host = m[1].replace(/^\[|\]$/g, ""); // tira colchetes de IPv6
  let port = parseInt(m[2], 10);
  return { host, port };
}

// Persiste em settings do VS Code (se webview) e também em localStorage (fallback)
function persistAddressPort(host, port) {
  // Estado local da Webview (restaura mesmo sem mensagem do host)
  if (vscode) {
    vscode.setState({ udpAddress: host, udpPort: port });
    vscode.postMessage({ type: 'saveAddressPort', host, port });
  }
  try {
    localStorage.setItem('lasecplot.udpAddress', host);
    localStorage.setItem('lasecplot.udpPort', String(port));
  } catch (_) {}
}

// Restaura de VS Code state / localStorage e aplica na UI
app.loadStoredAddressPort = function () {
  let host = '';
  let port = null;

  // 1) VS Code state (rápido)
  if (vscode) {
    const st = vscode.getState && vscode.getState();
    if (st && st.udpAddress) host = st.udpAddress;
    if (st && st.udpPort) port = st.udpPort;
  }

  // 2) Fallback localStorage
  try {
    if (!host) host = localStorage.getItem('lasecplot.udpAddress') || '';
    const p = localStorage.getItem('lasecplot.udpPort');
    if (p != null && p !== '' && !Number.isNaN(Number(p))) port = Number(p);
  } catch (_) {}

  // Aplica em app.configure (reativo)
  if (app.$set) {
    app.$set(app.configure, 'udpAddress', host || '');
    app.$set(app.configure, 'udpPort', port || null);
  } else {
    app.configure.udpAddress = host || '';
    app.configure.udpPort = port || null;
  }

  // Aplica nos inputs UDP existentes
  for (const c of (app.connections || [])) {
    const inputs = c.inputs || c.dataInputs || c.inputsList || [];
    for (const input of inputs) {
      if (input && input.type === 'UDP') {
        if (app.$set) {
          if (host) app.$set(input, 'address', host);
          if (port != null) app.$set(input, 'port', port);
        } else {
          if (host) input.address = host;
          if (port != null) input.port = port;
        }
      }
    }
  }
};

// Método chamado pelo botão "Connect" e pelo Enter no input
app.createConnection = function () {
  const parsed = parseHostPort(this.newConnectionAddress);
  if (!parsed) {
    alert("Use o formato host:porta (ex.: 127.0.0.1:47269)");
    return;
  }

  const { host, port } = parsed;

  // (1) Atualiza inputs UDP na UI
  for (const c of (this.connections || [])) {
    const inputs = c.inputs || c.dataInputs || c.inputsList || [];
    for (const input of inputs) {
      if (input && input.type === 'UDP') {
        if (this.$set) {
          this.$set(input, "address", host);
          this.$set(input, "port", port);
        } else {
          input.address = host;
          input.port = port;
        }
      }
    }
  }

  // (2) Atualiza app.configure (reativo)
  if (this.$set) {
    this.$set(this.configure, 'udpAddress', host);
    this.$set(this.configure, 'udpPort', port);
  } else {
    this.configure.udpAddress = host;
    this.configure.udpPort = port;
  }

  // (3) Persiste
  persistAddressPort(host, port);

  // (4) (Opcional) disparar reconexão WS/UDP com esse host/porta:
  // if (typeof this.reconnectAll === 'function') this.reconnectAll();
  // ou poste um evento para quem gerencia a conexão
  // if (vscode) vscode.postMessage({ type: 'reconnectUdp', host, port });

  // (5) Fecha modal e limpa campo
  this.creatingConnection = false;
  this.newConnectionAddress = "";
};

// Ouça mensagens do host para inicialização de config (VS Code)
window.addEventListener('message', (event) => {
  const msg = event.data || {};
  if (msg.type === 'initConfig') {
    const host = msg.udpAddress || '';
    const port = (msg.udpPort != null) ? Number(msg.udpPort) : null;

    if (app.$set) {
      app.$set(app.configure, 'udpAddress', host);
      app.$set(app.configure, 'udpPort', port);
    } else {
      app.configure.udpAddress = host;
      app.configure.udpPort = port;
    }
    // Aplica nos inputs
    for (const c of (app.connections || [])) {
      const inputs = c.inputs || c.dataInputs || c.inputsList || [];
      for (const input of inputs) {
        if (input && input.type === 'UDP') {
          if (app.$set) {
            if (host) app.$set(input, 'address', host);
            if (port != null) app.$set(input, 'port', port);
          } else {
            if (host) input.address = host;
            if (port != null) input.port = port;
          }
        }
      }
    }
  }
});

// Restaura ao carregar
app.loadStoredAddressPort();

//Init refresh rate
setInterval(updateView, 1000 / widgetFPS);


if(vscode){
    let conn = new ConnectionLasecPlotVSCode();
    conn.connect();
    app.connections.push(conn);
}
else {
    let conn = new ConnectionLasecPlotWebsocket();
    let addr = window.location.hostname;
    let port = window.location.port;
    conn.connect(addr, port);
    app.connections.push(conn);

    // Parse url params
    let params = new URLSearchParams(window.location.search);

    // Open layout from url
    let layout = params.get("layout")
    if (layout) {
        fetch(layout).then(res => res.blob()).then(blob => {
            importLayoutJSON({target:{files:[blob]}});
        });
    }
}


setInterval(()=>{
    for(let conn of app.connections){
        conn.updateCMDList();
    }
}, 3000);

